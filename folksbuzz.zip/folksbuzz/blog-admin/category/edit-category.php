<?php
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/functions.php');
include('../common/header.php');

//userPermissions($CONN, $USER_ROLE, 'site_users');  check the permission for user access read in function.php 
userPermissions($CONN, $USER_ROLE, 'listing'); 

if(isset($_GET['catid']))
{
   $ctid=clean_Input($_GET['catid']);
   $sql="SELECT * FROM category WHERE id=$ctid";
   $res=mysqli_query($CONN,$sql);
   $cdata=mysqli_fetch_assoc($res);

}


if(isset($_POST['submit']))
{

   $pid=clean_Input($_POST['category']);
   $name=clean_Input($_POST['name']);
   $slug=content_Slug($name);
   $menu = clean_Input($_POST['menu']);
   
   $csql="SELECT * FROM category WHERE (cat_name='$name' OR catslug='$slug') AND id!=$ctid AND menu = $menu";
   $cres=mysqli_query($CONN,$csql);
   if(!preg_match('/^[a-z0-9 .\-]+$/i',$name))
   {
      $_SESSION['error_msg']="Name must be Alphanumeric";
   }
   elseif(mysqli_num_rows($cres)>0)
   {
       $_SESSION['error_msg']="category Already Exist";
   }
  else
  {
         $sql="UPDATE category SET pid=$pid,cat_name='$name',catslug='$slug',menu = $menu WHERE id=$ctid";
         $res=mysqli_query($CONN,$sql);
         
        if($res)
         {
           $_SESSION['success_msg']='Category Updated successfully';  
            header("Location:category.php"); exit;	  
         }
       else 
        {
         $_SESSION['error_msg']="Category cannot be update";
        }  
   }

}


?>
<!-- End Top Navigation -->
<style>
.form-control{
	border:1px solid #ccc !important;
}
.title{
	font-size:22px !important;
	font-weight:bold;
}
</style>
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 

<!-- Left navbar-header end -->
 <!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Category</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
           <ol class="breadcrumb">
          	 <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>category/category.php">Category</a></li>
            <li class="active"> New Category </li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
	  <?php if(isset($_SESSION['success_msg'])) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($_SESSION['error_msg'])) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']);?>.
		</div>
	  <?php } ?>
      <!-- .row -->
	  <form class="form-horizontal" method='post' enctype='multipart/form-data' data-toggle='validator' role='form'>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="category.php">
					<i class="glyphicon glyphicon-search"></i> All category
				</a>
			</p>
            <div class="form-group col-md-6">
                <label class="col-md-12">Select Parent Category</label>
                <div class="col-md-12">
                  <select name='category' class='form-control'>
                    <option value="0" if(isset($cdata['pid'])==0){echo 'selected'; }>Default category</option>
                    <?php 
                    $category=fetchCategoryTree($CONN);
                    foreach($category as $ca)
                     {?>
                     	<option value="<?php echo $ca['id']; ?>" <?php if($cdata['pid']==$ca['catid']){ echo 'selected';}?>><?php echo $ca['name']; ?></option>
                     <?php } ?>
                 </select>             
                </div>
              </div>
              <div class="form-group col-md-6">
                <label class="col-md-12">Show in Menu</label>
                   <div class="col-md-10">
                      <input name='menu' type="radio" value="1" required="required" <?php if($cdata['menu'] == 1 ) { echo "checked"; }?>> Yes 
                      <input name='menu' type="radio" value="0" required="required" <?php if($cdata['menu'] == 0 ) { echo "checked"; }?>> No 
                      <div class="help-block with-errors"></div> 
                  </div>
			     </div>
              <div class="form-group col-md-12">
                <label class="col-md-12">Name</label>
                   <div class="col-md-10">
                      <input name='name' type="text" class="form-control" value="<?php echo $cdata['cat_name']; ?>" required="required">
                      <div class="help-block with-errors"></div> 
                  </div>
			     </div>
            <div class="form-group">
                <div class="col-lg-2 col-sm-4 col-xs-12">
					    <button class="btn btn-block btn-success" type='submit' name='submit' value='submit'>Submit</button>
				    </div>
           </div>
         </div>
      </div>
    </div>
      <!-- /.row -->
   </form>
      <!-- /.row -->
  </div>
    <!-- /.container-fluid -->
</div>
 <?php include('../common/footer.php'); ?>
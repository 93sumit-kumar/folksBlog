<?php
include('includes/session.php');
include('includes/config.php');
include('includes/logincheck.php');
include('common/header.php');
include('common/functions.php');
$sql="SELECt * FROM site_config";
$res=mysqli_query($CONN, $sql);
$siteData=mysqli_fetch_array($res);
?>
<!-- Left navbar-header -->
<?php include('common/leftmenu.php');?> 

<!-- Left navbar-header end -->
<style>
h4{
	font-weight:300;
}
.col-md-4 .white-box {
	min-height:400px;
}
</style>
<!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Dashboard </h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
        
          <ol class="breadcrumb">
            <li><a href="#">Dashboard</a></li>
            <li class="active"> Info </li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-md-12 col-lg-12 col-sm-12">
          <div class="white-box">
            <div class="row row-in">
              <div class="col-lg-3 col-sm-6 row-in-br">
                <div class="col-in row">
                  <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-user" ></i>
                    <h6 class="text-muted vb">Categories</h6>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-6">
                    <h3 class="counter text-right m-t-15 text-danger">
					       <h3 class="counter text-right m-t-15 text-megna">
					       
					        <?php 
					           $sql="SELECT COUNT(*) AS total_Category FROM category";
					           $res=mysqli_query($CONN, $sql);
					           $page=mysqli_fetch_assoc($res);
					           echo $page['total_Category'];
					          ?>
					       </h3>
							</h3>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="progress">
                      <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6 row-in-br  b-r-none">
                <div class="col-in row">
                  <div class="col-md-6 col-sm-6 col-xs-6">
				  <i class="glyphicon glyphicon-list-alt"></i>
                    <h6 class="text-muted vb">Pages</h6>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-6">
               <h3 class="counter text-right m-t-15 text-megna">
                    
					<?php 
					$sql="SELECT COUNT(*) AS total_course FROM contents WHERE status=1";
					$res=mysqli_query($CONN, $sql);
					$page=mysqli_fetch_array($res);
					echo $page['total_course'];
					?>
					</h3>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="progress">
                      <div class="progress-bar progress-bar-megna" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6 row-in-br">
                <div class="col-in row">
                  <div class="col-md-6 col-sm-6 col-xs-6"> <i class="fa fa-users"></i>
                    <h6 class="text-muted vb">Listing</h6>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-6">
                 	 <h3 class="counter text-right m-t-15 text-primary">
						<?php 
							$sql="SELECT COUNT(*) AS total_listing FROM listing WHERE status=1";
							$res=mysqli_query($CONN, $sql);
							$page=mysqli_fetch_array($res);
							echo $page['total_listing'];
						?>
						</h3>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="progress">
                      <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6  b-0">
                <div class="col-in row">
                  <div class="col-md-6 col-sm-6 col-xs-6"> <i class="glyphicon glyphicon-list-alt"></i>
                    <h6 class="text-muted vb">Ads Banners</h6>
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-6">
                    <h3 class="counter text-right m-t-15 text-success">
					<?php 
					$sql="SELECT COUNT(*) AS total_banner FROM advertisement WHERE status=1";
					$res=mysqli_query($CONN, $sql);
					$page=mysqli_fetch_array($res);
					echo $page['total_banner'];
					?>
					</h3>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="progress">
                      <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--row -->
      <div class="row">
        <div class="col-md-4 col-xs-12 col-sm-6">
          <div class="white-box">
            <h3 class="box-title"> Recent Category</h3>
            <div class="message-center"> 
					<?php 
						$sql	=	"SELECT * FROM category  ORDER BY id DESC LIMIT 8";
						$res	=	mysqli_query($CONN, $sql);
						while($category	=	mysqli_fetch_array($res)) {
					?> 
				 <a href="#">
           		 <div class="mail-contnet">
                <h5><?php echo ucfirst($category['cat_name']);?></h5>
              		<span class="time">
							<?php  //echo $category['create_date'];?>
						</span> 
					</div>
       		 </a> 
			  <?php } ?>
			  
			 </div>
          </div>
        </div>
        <div class="col-md-4 col-xs-12 col-sm-6">
          <div class="white-box">
            <h3 class="box-title">Recent Listing </h3>
         <div class="message-center"> 
			<?php 
			$sql="SELECT * FROM listing ORDER BY busiid DESC LIMIT 8";
			$res=mysqli_query($CONN, $sql);
			while($enquiry=mysqli_fetch_array($res)) {
			?>
			<a href="#">
              
              <div class="mail-contnet">
                <h5><?php echo ucfirst($enquiry['title']);?></h5>
                 <span class="time">
				<?php  //echo $enquiry['modify_date'];?>
				</span> 
				</div>
         </a> 
			  <?php } ?>
			  
			 </div>
          </div>
        </div>
		<div class="col-md-4 col-xs-12 col-sm-6">
          <div class="white-box">
            <h3 class="box-title"> Recent Paper (<span style="font-size:12px;"><a href="<?php echo $base_url;?>batch/batch.php"><b>All Paper</b></a>)</span></h3>
            <div class="message-center"> 
			<?php 
			$sql="SELECT * FROM contents ORDER BY id DESC LIMIT 8";		
			$res=mysqli_query($CONN, $sql);
			while($batch=mysqli_fetch_array($res)) {
			?>
			<a href="#">   
              <div class="mail-contnet">
                <h5><?php echo ucfirst($batch['title']);?></h5>
                 <span class="time">
				<?php  //echo $batch['create_date'];?>
				</span> 
				</div>
              </a> 
			  <?php } ?>
			  
			 </div>
          </div>
        </div>
   
      </div>
    
    <!-- /.container-fluid -->
 </div>
 <!--End Page Content -->
 <?php include('common/footer.php');?>
  
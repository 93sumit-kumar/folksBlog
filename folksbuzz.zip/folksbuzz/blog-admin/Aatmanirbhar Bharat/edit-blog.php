<?php
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('submit-edit-blog.php');
include('../common/header.php');
//userPermissions($CONN, $USER_ROLE, 'site_users');  check the permission for user access read in function.php 
//userPermissions($CONN, $USER_ROLE, 'content');  
if(isset($_GET['cid']))
{
	$cid=mysqli_real_escape_string($CONN, $_GET['cid']);
	$sql="SELECT * FROM blog WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	$data=mysqli_fetch_array($res);
}
?>
<!-- End Top Navigation -->
<style>
.form-control{
	border:1px solid #ccc !important;
}
.title{
	font-size:22px !important;
	font-weight:bold;
}
</style>
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<script>
function editUrl()
	{
		document.getElementById("page_url").readOnly = false;
		document.getElementById('page_url').focus();
	}
</script>
<!-- Left navbar-header end -->
 <!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Blogs</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
           <ol class="breadcrumb">
           	 <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>blog/index.php">Blogs</a></li>
            <li class="active"> Edit Blog </li>
		
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
	  <?php if(isset($success_msg)) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $success_msg; unset($success_msg);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($error_msg)) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $error_msg; unset($error_msg);?>.
		</div>
	  <?php } ?>
      <!-- .row -->
	  <form class="form-horizontal" method='post' enctype='multipart/form-data'>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="index.php">
					<i class="glyphicon glyphicon-search"></i> All Blogs
				</a>
			</p>
            <div class="form-group col-md-6">
                <label class="col-md-12">Blog Title</label>
                <div class="col-md-12">
				          <input type="hidden" name="content_id" value="<?php echo $cid;?>" />
                  <input name='ctitle' type="text" class="form-control" placeholder='Blog Title' value="<?php echo $data['blog_title'];?>" required="required" >
                </div>
              </div>
              <div class="form-group col-md-6">
                <label class="col-md-12" for="example-email">Slug <span class="help">(Page Url) </span></label>
                <div class="col-md-10">
                  <input name='slug' type="text" readonly id="page_url"  class="form-control" placeholder="Blog slug" value="<?php echo $data['slug'];?>">
                </div>
				          <a href="javascript:void(0);" onClick="editUrl()" style="color:#000">Edit Slug</a>
              </div>
			        <div class="form-group">
                <label class="col-md-12">Full Content</label>
                <div class="col-md-12">
                  <textarea class="form-control" rows="5" id="content" name='content' cols='50'><?php echo $data['content'];?></textarea>
                </div>
              </div>
			        <div class="form-group">
                <label class="col-md-12">Select Category</label>
                <div class="col-md-6">
                  <select class="form-control" name='pid'>
                    <option value="0">Default Category</option>
                    <?php
                    $sql="SELECT * FROM category WHERE status=1 AND id!=".$cid." ORDER BY cat_name";
                    $res=mysqli_query($CONN, $sql);
                    while($cdata=mysqli_fetch_array($res)) {
                    ?>
                              <option value="<?php echo $cdata['id']; ?>"  <?php if($cdata['id']==$data['pid']) { echo "selected"; }?>><?php echo $cdata['cat_name']; ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
			        <div class="form-group">
                <label class="col-md-2" style="font-weight:bold;">Show in Menu</label>
                <div class="col-md-6">
                      <div class="radio-list">
                          <label><input name="menu" value="1" type="radio" <?php if($data['menu']==1) { echo "checked"; }?>> Yes </label> &nbsp;
                          <label> <input name="menu" value="0" type="radio" <?php if($data['menu']==0) { echo "checked"; }?>>No </label>
                      </div>
                  </div>
              </div>
              <div class="form-group">
                <label class="col-sm-12">Featured Image</label>
                <div class="col-sm-12">
                  <img src="../../uploads/media/<?php echo $data['blog_image'];?>" width="300" height="120" /> 
                  <br/> <br/>
                  <input type="file" name='image' class="form-control" style="padding-bottom: 40px !important;">
                </div>
              </div>
 
          </div>
        </div>
      </div>
      <!-- /.row -->
	    <!-- .row -->
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
			  <h3 class="box-title m-b-0 title">Related to On-Page SEO</h3><br>            
                <div class="form-group">
                <label class="col-md-12">Meta Title<span class="help"> </span></label>
                <div class="col-md-12">
                  <input type="text" name='meta_title' class="form-control" value="<?php echo $data['meta_title'];?>" placeholder="Meta Title">
                </div>
              </div>
                      
              <div class="form-group">
                <label class="col-md-12">Meta Keyword</label>
                <div class="col-md-12">
                  <textarea name='meta_key' class="form-control" rows="3" placeholder='Enter Your Comm Separated Meta keywords'><?php echo $data['keywords'];?></textarea>
                </div>
              </div>
			        <div class="form-group">
                <label class="col-md-12">Meta Description</label>
                <div class="col-md-12">
                  <textarea name='meta_desc' class="form-control" rows="3" placeholder='Enter Your Meta Description Here'><?php echo $data['description'];?></textarea>
                </div>
              </div>
			  
			        <div class="form-group">
                <div class="col-lg-2 col-sm-4 col-xs-12">
					        <button class="btn btn-block btn-success" type='submit' name='submit' value='submit'>Submit</button>
				        </div>
              </div>
        
          </div>
        </div>
      </div>
	   </form>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
 <?php include('../common/footer.php'); ?>
 <script src="../ckeditor/ckeditor.js"></script>
<script>
        CKEDITOR.replace( 'content' );
</script>
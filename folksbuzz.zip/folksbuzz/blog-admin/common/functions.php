<?php
function clean($conn,$data)
{
    $data=mysqli_real_escape_string($conn,$data);
  	$data=htmlspecialchars($data);
	return $data;
}
/***** Return Type Name Using Type Id*******/
function getTypeName($conn,$id)
{
	$sql="SELECT type_name FROM type WHERE id=$id";
	$res=mysqli_query($conn,$sql);
	$data=mysqli_fetch_assoc($res);
	
	return $data['type_name'];

}

/**
 * @Description : Function to get the user data by ID
 * @param : user_id
 * @return : return user data
 */
function getTheUserData($CONN,$userID) {
  $sql = "SELECT * FROM users WHERE uid = $userID";
  $res = mysqli_query($CONN,$sql);
  $data = mysqli_fetch_assoc($res);
  return $data;
}
  

function sendEmail($email,$subject,$message)
  {
	   $mail = new PHPMailer();
       $mail->IsSMTP();                                      // set mailer to use SMTP
       $mail->From = "ykskills.com";
       $mail->FromName = "Yk Exam";
       $mail->AddAddress($email);
       //$mail->addBCC('customer.service@worldofwheelz.in');
	   $mail->WordWrap = 50;                                 // set word wrap to 50 characterse
       $mail->IsHTML(true);   
       $mail->Subject = $subject;
       $mail->Body=$message;  
       $mail->Send();
	
	
  }
?>
<?php
/*-----------------------------------------------------------------------------------
| $USER_ID is defined in logincheck.php file which is stored in include directory
-----------------------------------------------------------------------------------*/
if(isset($_POST['submit']))
{
	$sql="SELECT * FROM media_settings WHERE id=1";
	$res=mysqli_query($CONN, $sql);
	$Media=mysqli_fetch_array($res);
	
	$content_id=$_POST['content_id'];
	$ctitle=mysqli_real_escape_string($CONN,$_POST['ctitle']);
	$slug=mysqli_real_escape_string($CONN,$_POST['slug']);
	$content=mysqli_real_escape_string($CONN,$_POST['content']);
	$pid=mysqli_real_escape_string($CONN,$_POST['pid']);
	$menu=mysqli_real_escape_string($CONN,$_POST['menu']);
	$meta_title=mysqli_real_escape_string($CONN,$_POST['meta_title']);
	$meta_key=mysqli_real_escape_string($CONN,$_POST['meta_key']);
	$meta_desc=mysqli_real_escape_string($CONN,$_POST['meta_desc']);
	if($slug==''){
		$slug=content_Slug($ctitle);
	} else {
		$slug=content_Slug($slug);
	}
	if($ctitle=='' || $content=='')
	{
		$_SESSION['error_msg']="Blog Title and Blog Description are Required";
	}
	else
	{
		$sql="SELECT * FROM blog WHERE blog_title='$ctitle' AND id!=".$content_id;
		$res=mysqli_query($CONN, $sql);
		if(mysqli_num_rows($res)!=0)
		{
			$_SESSION['error_msg']='Blog with this title already exists';
		}
		else
		{
			if($USER_ROLE == 2) {
				$display = "display = 0";
			} else {
				$display = "display = 1";
			}
			if(isset($_FILES['image']) AND $_FILES['image']['name']!='')
			{
				$fname=rand(101,99999);
				$imgname=$_FILES["image"]['name'];
				$filename=$fname.$_FILES['image']['name'];
				$source = $_FILES["image"]['tmp_name'];
				$target = '../../uploads/media/'.$filename;
				//move_uploaded_file($source, $target); 
				$nwidth=$Media['feature_width'];
				$nheight=$Media['feature_height'];
				$imgReturn=imageUpload($imgname, $source, $target, $nwidth, $nheight);
				if($imgReturn==3)
				{
					$sql="UPDATE blog SET blog_title='$ctitle', slug='$slug', content='$content', $display, blog_image='$filename', cat_id=$pid, menu=$menu,meta_title='$meta_title', keywords='$meta_key', description = '$meta_desc', update_date='$DATETIME', author=$USER_ID WHERE id=".$content_id;
				}
				else
				{
					$_SESSION['error_msg']=$imgReturn;
				}
			}
			else
			{
				$sql="UPDATE blog SET blog_title='$ctitle', slug='$slug', content='$content', $display, cat_id=$pid, menu=$menu,meta_title='$meta_title', keywords='$meta_key', description = '$meta_desc', update_date='$DATETIME', author=$USER_ID WHERE id=".$content_id;
			}
			if(!isset($_SESSION['error_msg'])) 
			{
				$res=mysqli_query($CONN, $sql);
				if(mysqli_affected_rows($CONN)==1)
				{
					$_SESSION['success_msg']="Blog Update Successfully";
				}
				else
				{
					$_SESSION['error_msg']="Blog not Update, Please try again";
				}
			}
		}
	}
	header('Location:index.php'); exit;
}

?>
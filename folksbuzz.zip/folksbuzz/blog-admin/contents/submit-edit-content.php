<?php
/*-----------------------------------------------------------------------------------
| $USER_ID is defined in logincheck.php file which is stored in include directory
-----------------------------------------------------------------------------------*/
if(isset($_POST['submit']))
{
	$sql="SELECT * FROM media_settings WHERE id=1";
	$res=mysqli_query($CONN, $sql);
	$Media=mysqli_fetch_array($res);
	
	$content_id=$_POST['content_id'];
	$ctitle=mysqli_real_escape_string($CONN,$_POST['ctitle']);
	$slug=mysqli_real_escape_string($CONN,$_POST['slug']);
	$content=mysqli_real_escape_string($CONN,$_POST['content']);
	$pid=mysqli_real_escape_string($CONN,$_POST['pid']);
	$menu=mysqli_real_escape_string($CONN,$_POST['menu']);
	$meta_title=mysqli_real_escape_string($CONN,$_POST['meta_title']);
	$meta_key=mysqli_real_escape_string($CONN,$_POST['meta_key']);
	$meta_desc=mysqli_real_escape_string($CONN,$_POST['meta_desc']);
	if($slug==''){
		$slug=content_Slug($ctitle);
	} else {
		$slug=content_Slug($slug);
	}
	if($ctitle=='' || $content=='')
	{
		$_SESSION['error_msg']="Content Title and Content Description are Required";
	}
	else
	{
		$sql="SELECT * FROM contents WHERE title='$ctitle' AND id!=".$content_id;
		$res=mysqli_query($CONN, $sql);
		if(mysqli_num_rows($res)!=0)
		{
			$_SESSION['error_msg']='Content with this title already exists';
		}
		else
		{
			if(isset($_FILES['image']) AND $_FILES['image']['name']!='')
			{
				$fname=rand(101,99999);
				$imgname=$_FILES["image"]['name'];
				$filename=$fname.$_FILES['image']['name'];
				$source = $_FILES["image"]['tmp_name'];
				$target = '../../uploads/media/'.$filename;
				//move_uploaded_file($source, $target); 
				$nwidth=$Media['feature_width'];
				$nheight=$Media['feature_height'];
				$imgReturn=imageUpload($imgname, $source, $target, $nwidth, $nheight);
				if($imgReturn==3)
				{
					$sql="UPDATE contents SET title='$ctitle', slug='$slug', content='$content', feature_image='$filename', pid=$pid, menu=$menu,meta_title='$meta_title', meta_key='$meta_key', meta_desc='$meta_desc', modified_date='$DATETIME', userid=$USER_ID WHERE id=".$content_id;
				}
				else
				{
					$_SESSION['error_msg']=$imgReturn;
				}
			}
			else
			{
				$sql="UPDATE contents SET title='$ctitle', slug='$slug', content='$content', pid=$pid, menu=$menu,meta_title='$meta_title', meta_key='$meta_key', meta_desc='$meta_desc', modified_date='$DATETIME', userid=$USER_ID WHERE id=".$content_id;
			}
			if(!isset($_SESSION['error_msg'])) 
			{
				$res=mysqli_query($CONN, $sql);
				if(mysqli_affected_rows($CONN)==1)
				{
					$_SESSION['success_msg']="Content Update Successfully";
				}
				else
				{
					$_SESSION['error_msg']="Content not Update, Please try again";
				}
			}
		}
	}
	header('Location:contents.php'); exit;
}

?>
<?php
/*-----------------------------------------------------------------------------------
| $USER_ID is defined in logincheck.php file which is stored in include directory
-----------------------------------------------------------------------------------*/
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/header.php');
include('../common/functions.php');
//userPermissions($CONN, $USER_ROLE, 'site_users');  check the permission for user access read in function.php 
userPermissions($CONN, $USER_ROLE, 'listing');  


if(isset($_GET['fulldelete']))
{
	$catid=clean($_GET['fulldelete']);
	$sql="DELETE FROM category WHERE id=".$catid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Category Deleted  permanently';
	} else {
		$_SESSION['error_msg']='Course not deleted, Please try again';
	}
	header('Location:category.php?action=trash'); exit;
}

?>
<!-- End Top Navigation -->
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<!-- Left navbar-header end -->
<!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Category</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
             <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>category/category.php">Category</a></li>
            <li class="active">Category</li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- /row -->
	  
	  <?php if(isset($_SESSION['success_msg'])) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($_SESSION['error_msg'])) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']);?>.
		</div>
	  <?php } ?>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="new-category.php">
					<i class="glyphicon glyphicon-plus"></i> Add New
				</a>
				<?php
					if(isset($_GET['action']) && $_GET['action']=='trash'){
				?>	
				<a class="btn btn-success" href="course.php">
					<i class="glyphicon glyphicon-search"></i> All category
				</a>
				<?php } else { ?>
				<a class="btn btn-danger" href="course.php?action=trash">
					<i class="glyphicon glyphicon-trash"></i> View Trash
				</a>
				<?php } ?>
			</p>
           <div class="table-responsive">
           
			<table id="myTable" class="table table-striped table-bordered dataTable" role="grid" aria-describedby="table_info" style="width: 100%;" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th style="width:30px !important;" >S.No</th>
                  <th>Name</th>
                  <th>Parent name</th>                  
                 <th>Actions</th>
                </tr>
              </thead>
              <tbody>
             <?php            
                $i=1;
                 	$csql="SELECT * FROM category WHERE status = 1";                
                 $cres=mysqli_query($CONN,$csql);
               while($bdata=mysqli_fetch_assoc($cres)){
              ?>
               <tr>
               <td><?php echo $i; ?></td>
               <td><?php echo $bdata['cat_name']; ?></td>
               <td><?php echo getParentCategoryName($CONN,$bdata['pid']); ?></td>
               <td> 
               <?php if($USER_ROLE==1){?>
               <a class="btn btn-sm btn-primary action" href="edit-category.php?catid=<?php echo $bdata['id'];?>" title="Edit" onclick="edit_person('11088')">
                  <i class="glyphicon glyphicon-pencil"></i> </a>
               <a class="btn btn-sm btn-danger action" href="category.php?fulldelete=<?php echo $bdata['id']; ?>" title="Delete This Permanently " onclick="return confirm('Do you really want to delete this permanently');">
				      <i class="glyphicon glyphicon-remove-sign"></i> </a>
              <?php } ?>
				  </td>
				  </tr>
               <?php $i++;} ?>
              </tbody>
			  
            </table>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    
    </div>
    <!-- /.container-fluid -->
   
  </div>
  
 <?php include('../common/footer.php');?>
 
 
 
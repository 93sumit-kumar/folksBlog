<?php
/*-----------------------------------------------------------------------------------
| $USER_ID is defined in logincheck.php file which is stored in include directory
-----------------------------------------------------------------------------------*/
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/header.php');
//userPermissions($CONN, $USER_ID, 'site_users');  check the permission for user access read in function.php 
userPermissions($CONN, $USER_ID, 'content');  
if(isset($_GET['delete']))
{
	$cid=$_GET['delete'];
	$sql="UPDATE contents SET status=0, userid=$USER_ID WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Content move in Trash Successfully';
	} else {
		$_SESSION['error_msg']='Content not move in Trash, Please try again';
	}
	header('Location:contents.php'); exit;
}

if(isset($_GET['fulldelete']))
{
	$cid=$_GET['fulldelete'];
	$sql="DELETE FROM contents WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Content Deleted  permanently';
	} else {
		$_SESSION['error_msg']='Content not deleted, Please try again';
	}
	header('Location:contents.php?action=trash'); exit;
}
if(isset($_GET['untrash']))
{
	$cid=$_GET['untrash'];
	$sql="UPDATE contents SET status=1, userid=$USER_ID WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Content Un-Trash Successfully';
	} else {
		$_SESSION['error_msg']='Content not Un-Trash , Please try again';
	}
	header('Location:contents.php'); exit;
}
?>
<!-- End Top Navigation -->
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<!-- Left navbar-header end -->
<!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Contents</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
             <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>contents/contents.php">Contents</a></li>
            <li class="active">All Contents</li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- /row -->
	  
	  <?php if(isset($_SESSION['success_msg'])) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($_SESSION['error_msg'])) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']);?>.
		</div>
	  <?php } ?>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="new-content.php">
					<i class="glyphicon glyphicon-plus"></i> Add New
				</a>
				<?php
					if(isset($_GET['action']) && $_GET['action']=='trash'){
				?>	
				<a class="btn btn-success" href="contents.php">
					<i class="glyphicon glyphicon-search"></i> All Contents
				</a>
				<?php } else { ?>
				<a class="btn btn-danger" href="contents.php?action=trash">
					<i class="glyphicon glyphicon-trash"></i> View Trash
				</a>
				<?php } ?>
			</p>
            <div class="table-responsive">
           
			<table id="myTable" class="table table-striped table-bordered dataTable" role="grid" aria-describedby="table_info" style="width: 100%;" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th style="width:30px !important;" >S.No</th>
                  <th>Title</th>
                  <th>Parent Menu</th>
                  <th>Image</th>
                  <th>Modify Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
               <tbody>
			    <?php 
				$ii=1;
				if(isset($_GET['action']) && $_GET['action']=='trash'){
					$sql="SELECT * FROM contents WHERE status=0";
				} else {
					$sql="SELECT * FROM contents WHERE status=1";
				}
				$res=mysqli_query($CONN, $sql);
				while($data=mysqli_fetch_array($res))
				{
				?>
                <tr>
                  <td><?php echo $ii;?></td>
                  <td><?php echo $data['title'];?></td>
                  <td>
				  <?php 
					$csql="SELECT * FROM contents WHERE id=".$data['pid'];
					$cres=mysqli_query($CONN, $csql);
					if(mysqli_num_rows($cres)==1){
						$pmenu=mysqli_fetch_array($cres);
						echo $pmenu['title'];
					} else {
						echo "Default Parent";
					}
				  ?>
				  </td>
                  <td><img src='../../uploads/media/<?php echo $data['feature_image']; ?>' width='40' height='40'  /></td>
                  <td>
					<?php 
						$tt=strtotime($data['modified_date']);
						echo date('d-M-Y H:i:s', $tt);
						
					?>
				  </td>
                  <td>
				   <a class="btn btn-sm btn-info action" href="view-Detail.php?cid=<?php echo $data['id'];?>" title="View" onclick="viewDetail(<?php echo $data['id']; ?>)"><i class="glyphicon glyphicon-zoom-in"></i> </a>
				   <a class="btn btn-sm btn-primary action" href="edit-content.php?cid=<?php echo $data['id'];?>" title="Edit" onclick="edit_person('11088')"><i class="glyphicon glyphicon-pencil"></i> </a>
				  <?php 
					if(isset($_GET['action']) && $_GET['action']=='trash'){ 
					 if($USER_ROLE==1) {
					?>
				  <a class="btn btn-sm btn-danger action" href="contents.php?fulldelete=<?php echo $data['id']; ?>" title="Delete This Permanently " onclick="return confirm('Do you really want to delete this permanently');">
				  <i class="glyphicon glyphicon-remove-sign"></i> </a>
					<?php } ?>
				   <a class="btn btn-sm btn-warning action" href="contents.php?untrash=<?php echo $data['id']; ?>" title="Un-Trash This " onclick="return confirm('Do you want Un-trash this');">
				  Un-Trash </a>
				  <?php } else { ?>
				    <a class="btn btn-sm btn-danger action" href="contents.php?delete=<?php echo $data['id']; ?>" title="Move in Trash" onclick="return confirm('Do you want to move this in Trash');"><i class="glyphicon glyphicon-trash"></i> </a>
				  <?php } ?>
				  </td>
                </tr>
				<?php $ii++; } ?>
				               
            
               
               
              </tbody>
			  
            </table>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    
    </div>
    <!-- /.container-fluid -->
   
  </div>
  
 <?php include('../common/footer.php');?>
 
 
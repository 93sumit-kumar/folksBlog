<?php
/*-----------------------------------------------------------------------------------
| $USER_ID is defined in logincheck.php file which is stored in include directory
-----------------------------------------------------------------------------------*/
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/header.php');
//userPermissions($CONN, $USER_ID, 'site_users');  check the permission for user access read in function.php 
//userPermissions($CONN, $USER_ID, 'content');  
if(isset($_GET['approve'])){
	$id = $_GET['approve'];
	$sql = "UPDATE aatmanirbhar_bharat SET display=1 WHERE id= $id";
	$res = mysqli_query($CONN,$sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Blog approved Successfully';
	} else {
		$_SESSION['error_msg']='Blog not approved, Please try again';
	}
	header('Location:index.php'); exit;
}
if(isset($_GET['pending'])){
	$id = $_GET['pending'];
	$sql = "UPDATE aatmanirbhar_bharat SET display=0 WHERE id= $id";
	$res = mysqli_query($CONN,$sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Blog moved to pending Successfully';
	} else {
		$_SESSION['error_msg']='Blog not moved to pending, Please try again';
	}
	header('Location:index.php'); exit;
}
if(isset($_GET['delete']))
{
	$cid=$_GET['delete'];
	$sql="UPDATE blog SET status=0, author=$USER_ID WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Blog move in Trash Successfully';
	} else {
		$_SESSION['error_msg']='Blog not move in Trash, Please try again';
	}
	header('Location:index.php'); exit;
}

if(isset($_GET['fulldelete']))
{
	$cid=$_GET['fulldelete'];
	$sql="DELETE FROM blog WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Blog Deleted  permanently';
	} else {
		$_SESSION['error_msg']='Blog not deleted, Please try again';
	}
	header('Location:index.php?action=trash'); exit;
}
if(isset($_GET['untrash']))
{
	$cid=$_GET['untrash'];
	$sql="UPDATE blog SET status=1, author=$USER_ID WHERE id=".$cid;
	$res=mysqli_query($CONN, $sql);
	if(mysqli_affected_rows($CONN)==1){
		$_SESSION['success_msg']='Blog Un-Trash Successfully';
	} else {
		$_SESSION['error_msg']='Blog not Un-Trash , Please try again';
	}
	header('Location:index.php'); exit;
}
?>
<!-- End Top Navigation -->
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<!-- Left navbar-header end -->
<!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Blogs</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
             <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>blog/index.php">Blog</a></li>
            <li class="active">All Blogs</li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- /row -->
	  
	  <?php if(isset($_SESSION['success_msg'])) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($_SESSION['error_msg'])) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']);?>.
		</div>
	  <?php } ?>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="new-blog.php">
					<i class="glyphicon glyphicon-plus"></i> Add New Blog 
				</a>
				<?php
					if(isset($_GET['action']) && $_GET['action']=='trash'){
				?>	
				<a class="btn btn-success" href="index.php">
					<i class="glyphicon glyphicon-search"></i> All Blogs
				</a>
				<?php } else { ?>
				<a class="btn btn-danger" href="index.php?action=trash">
					<i class="glyphicon glyphicon-trash"></i> View Trash
				</a>
				<?php } ?>
			</p>
            <div class="table-responsive">
           
			<table id="myTable" class="table table-striped table-bordered dataTable" role="grid" aria-describedby="table_info" style="width: 100%;" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th style="width:30px !important;" >S.No</th>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Image</th>
                  <th>Approve</th>
                  <th>Update Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
               <tbody>
				<?php 
				if($USER_ROLE == 2) {
					$whereQuery = "author = $USER_ID AND";
				} else {
					$whereQuery = "";
				}
				$ii=1;
				if(isset($_GET['action']) && $_GET['action']=='trash'){
					$sql="SELECT * FROM blog WHERE $whereQuery status=0";
				} else {
					$sql="SELECT * FROM blog WHERE $whereQuery status=1";
				}
				$res=mysqli_query($CONN, $sql);
				while($data=mysqli_fetch_array($res))
				{
				?>
                <tr>
                  <td><?php echo $ii;?></td>
                  <td><?php echo $data['blog_title'];?></td>
                  <td>
				  <?php 
					$csql="SELECT * FROM category WHERE id=".$data['cat_id'];
					$cres=mysqli_query($CONN, $csql);
					if(mysqli_num_rows($cres)==1){
						$pmenu=mysqli_fetch_array($cres);
						echo $pmenu['cat_name'];
					} else {
						echo "Default Category";
					}
				  ?>
				  </td>
                  <td><img src='../../uploads/media/<?php echo $data['blog_image']; ?>' width='40' height='40'  /></td>
                  <td>
					<?php
					/**
					 * This code is related to approved by admin
					 */
					if($USER_ROLE == 1){
						if($data['display'] == 0) { ?>
							<a href="index.php?approve=<?php echo $data['id']; ?>" class="label label-danger" style="font-size: 12px" title="Clieck to Approve">Pending</a>
						<?php } else { ?>
							<a href="index.php?pending=<?php echo $data['id'];?>"class="label label-success" style="font-size: 12px" title="Click to Pending">Approved</a>
					<?php	
						}	
					} else {
						if($data['display'] == 1) {
					?>
						<span style="color: #00c292">Approved</span>
						<?php } else { ?>
						<span style="color: #fb9678">Waiting for approve by admin</span>
					<?php } } ?>
					</td>
				  <td>
					<?php 
						$tt=strtotime($data['update_date']);
						echo date('d-M-Y H:i:s', $tt);
						
					?>
				  </td>
                  <td>
				   <a class="btn btn-sm btn-info action" href="view-Detail.php?cid=<?php echo $data['id'];?>" title="View" onclick="viewDetail(<?php echo $data['id']; ?>)"><i class="glyphicon glyphicon-zoom-in"></i> </a>
				   <a class="btn btn-sm btn-primary action" href="edit-blog.php?cid=<?php echo $data['id'];?>" title="Edit" onclick="edit_person('11088')"><i class="glyphicon glyphicon-pencil"></i> </a>
				  <?php 
					if(isset($_GET['action']) && $_GET['action']=='trash'){ 
					 if($USER_ROLE==1) {
					?>
				  <a class="btn btn-sm btn-danger action" href="index.php?fulldelete=<?php echo $data['id']; ?>" title="Delete This Permanently " onclick="return confirm('Do you really want to delete this permanently');">
				  <i class="glyphicon glyphicon-remove-sign"></i> </a>
					<?php } ?>
				   <a class="btn btn-sm btn-warning action" href="index.php?untrash=<?php echo $data['id']; ?>" title="Un-Trash This " onclick="return confirm('Do you want Un-trash this');">
				  Un-Trash </a>
				  <?php } else { if($USER_ROLE != 2) { ?>
				    <a class="btn btn-sm btn-danger action" href="index.php?delete=<?php echo $data['id']; ?>" title="Move in Trash" onclick="return confirm('Do you want to move this in Trash');"><i class="glyphicon glyphicon-trash"></i> </a>
				  <?php } } ?>
				  </td>
                </tr>
				<?php $ii++; } ?>
				               
            
               
               
              </tbody>
			  
            </table>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    
    </div>
    <!-- /.container-fluid -->
   
  </div>
  
 <?php include('../common/footer.php');?>
 
 
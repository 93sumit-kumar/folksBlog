<?php
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/header.php');
//userPermissions($CONN, $USER_ROLE, 'site_users');  check the permission for user access read in function.php 
userPermissions($CONN, $USER_ROLE, 'content');  
$contid=mysqli_real_escape_string($CONN,$_GET['cid']);
$sql="SELECT * FROM contents WHERE id=".$contid;
$res=mysqli_query($CONN, $sql);
$data=mysqli_fetch_array($res);
?>
<style>
.form-horizontal .control-label {
    padding-top: 7px;
    margin-bottom: 0;
    text-align: left !important;
	font-weight:500;
	font-size:18px
}
</style>
<!-- End Top Navigation -->
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<!-- Left navbar-header end -->
<!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Contents</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
           <ol class="breadcrumb">
            <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>contents/contents.php">Contents</a></li>
            <li class="active">View Detail	</li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- /row -->
      <div class="row">
       
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="new-content.php">
					<i class="glyphicon glyphicon-plus"></i> Add New
				</a>
				<a class="btn btn-success" href="contents.php">
					<i class="glyphicon glyphicon-search"></i> All Contents
				</a>
			</p>
           <div class="row">
        <div class="col-md-12">
          <div class="panel panel-info">
            <div class="panel-wrapper collapse in" aria-expanded="true">
              <div class="panel-body">
                 <form class="form-horizontal" role="form">
              <div class="form-body">
             
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Content Title:</label>
                      <div class="col-md-8">
                        <p class="form-control-static">  <?php echo $data['title'];?> </p>
                      </div>
                    </div>
                  </div>
				   <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Content Slug:</label>
                      <div class="col-md-8">
                        <p class="form-control-static">  <?php echo $data['slug'];?> </p>
                      </div>
                    </div>
                  </div>
				   <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Full Content:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> <?php echo $data['content'];?> </p>
                      </div>
                    </div>
                  </div>
				   <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Parent Menu:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> 
						<?php 
						$pid= $data['pid'];
						$sql="SELECT * FROM contents WHERE id=".$pid;
						$res=mysqli_query($CONN, $sql);
						$pdata=mysqli_fetch_array($res);
						if(mysqli_num_rows($res)==0){
							echo "Default Menu";							
						} else {
							echo $pdata['title'];
						}
						?> </p>
                      </div>
                    </div>
                  </div>
				   <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Show in Menu:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> 
							<?php 
							 if($data['menu']==0) {
								 echo "No";
							 } else {
								 echo "Yes";
							 }
						    ?> 
						</p>
                      </div>
                    </div>
                  </div>
				   <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Featured Image:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> 
						 <img src="../../uploads/media/<?php echo $data['feature_image'];?>" width="500" height="250" /> </p>
                      </div>
                    </div>
                  </div>
				 
				  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Meta Title:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> <?php echo $data['meta_title'];?> </p>
                      </div>
                    </div>
                  </div>
				  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Meta Keyword:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> <?php echo $data['meta_key'];?> </p>
                      </div>
                    </div>
                  </div>
				    <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label col-md-3">Meta Description:</label>
                      <div class="col-md-8">
                        <p class="form-control-static"> <?php echo $data['meta_desc'];?> </p>
                      </div>
                    </div>
                  </div>
				  
                
                </div>
                <!--/row-->
            
             
              </div>
           
            </form>
              </div>
            </div>
          </div>
        </div>
      </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    
    </div>
    <!-- /.container-fluid -->
   
  </div>
  
 <?php include('../common/footer.php');?>
 
 
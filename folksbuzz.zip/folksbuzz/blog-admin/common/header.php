<!DOCTYPE html>  
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="webseekers" >
<link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
<title>Webcarton Xo-Lite</title>
<!-- Bootstrap Core CSS -->
<link href="<?php echo $base_url;?>bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Menu CSS -->
<link href="<?php echo $base_url;?>plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
<!-- toast CSS -->
<link href="<?php echo $base_url;?>plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
<!-- morris CSS -->
<link href="<?php echo $base_url;?>plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
<!-- animation CSS -->
<link href="<?php echo $base_url;?>css/animate.css" rel="stylesheet">
<link href="<?php echo $base_url;?>css/jquery-ui.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="<?php echo $base_url;?>css/style.css" rel="stylesheet">
<!-- color CSS -->
<link href="<?php echo $base_url;?>css/colors/blue-dark.css" id="theme"  rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.4/css/select2.min.css" rel="stylesheet" />
<link href="<?php echo $base_url; ?>plugins/bower_components/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $base_url; ?>cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />
	
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
#myTable_filter input{
height: 28px !important;
border: 1px solid #ccc !important;
}
table.dataTable {
       border: 1px solid #ccc !important;
}
.action {
    padding: 5px 10px !important;
}
tbody{
	color: #121111 !important;
}
.alert{
	font-size:18px !important;
}
.table.dataTable thead th, table.dataTable thead td {
    padding: 10px 6px !important;
    border-bottom: 1px solid #111;
}
</style>
</head>
<body>
<!-- Preloader -->
<div id="wrapper">
  <!-- Navigation -->
<nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part">&nbsp;<a class="logo" href="index.html"><b><img src="<?php echo $base_url;?>plugins/images/logo.png" alt="home" width="162px"/></b></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
        <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light">
		<i class="icon-arrow-left-circle ti-menu"></i></a></li>
		
       
      </ul>
      <ul class="nav navbar-top-links navbar-right pull-right">
      
        <!-- /.dropdown -->
        <li class="dropdown"> 
		<a class="dropdown-toggle waves-effect waves-light" d href="<?php echo $base_url;?>logout.php" title="Logout">
			<i class="fa fa-power-off"></i>
          <div class="notify"><span class="heartbit"></span><span class="point"></span></div>
        </a>
        <!-- /.dropdown-tasks -->
        </li>
        <!-- /.dropdown -->
        <li class="dropdown"> 
        <a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#"> 
        	<!-- <img src="<?php echo $base_url;?>uploads/profile/<?php echo $USER_DATA['photo']; ?>" alt="user-img" width="50" height="50" class=""><b class="hidden-xs"> -->
				<?php echo $_SESSION['username'];?>
				</b> 
			</a>
          <ul class="dropdown-menu dropdown-user animated flipInY">
            <li><a href="<?php echo $base_url;?>users/profile.php"><i class="ti-user"></i> My Profile</a></li>
            <li role="separator" class="divider"></li>
			  <li><a href="<?php echo $base_url;?>users/password.php"><i class="glyphicon glyphicon-lock"></i> Change Password</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="<?php echo $base_url;?>logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
          </ul>
          <!-- /.dropdown-user -->
        </li>
       <!-- /.dropdown -->
      </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
</nav>
 
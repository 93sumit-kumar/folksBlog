/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'pt', {
	fontSize: {
		label: 'Tamanho',
		voiceLabel: 'Tamanho da letra',
		panelTitle: 'Tamanho da letra'
	},
	label: 'Fonte',
	panelTitle: 'Nome do tipo de letra',
	voiceLabel: 'Tipo de letra'
} );

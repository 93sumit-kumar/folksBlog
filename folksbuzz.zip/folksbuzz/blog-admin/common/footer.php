 <footer class="footer text-center"> 2009 - <?php echo date('Y');?> &copy; <a href="#" target="_blank">TechTrap</a> [A <a href="#" target="_blank">Tech Trapped</a> Product]</footer>
  <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<!-- jQuery -->
<script src="<?php echo $base_url;?>plugins/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo $base_url;?>bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo $base_url;?>js/validator.js"></script>
<!-- Menu Plugin JavaScript -->
<!--slimscroll JavaScript -->
<script src="<?php echo $base_url;?>js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="<?php echo $base_url;?>js/waves.js"></script>
<script src="<?php echo $base_url;?>js/jquery-ui.js"></script>
<!--Counter js -->
<script src="<?php echo $base_url;?>plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
<script src="<?php echo $base_url;?>plugins/bower_components/counterup/jquery.counterup.min.js"></script>
<!--Morris JavaScript -->
<script src="<?php echo $base_url;?>plugins/bower_components/raphael/raphael-min.js"></script>
<script src="<?php echo $base_url;?>plugins/bower_components/morrisjs/morris.js"></script>
<!-- Custom Theme JavaScript -->
<script src="<?php echo $base_url;?>js/custom.min.js"></script>
<script src="<?php echo $base_url;?>js/wp-sidebar.js"></script>
<!-- Sparkline chart JavaScript -->
<script src="<?php echo $base_url;?>plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo $base_url;?>plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
<!--Style Switcher -->
 <script src="<?php echo $base_url; ?>plugins/bower_components/datatables/jquery.dataTables.min.js"></script>
<!-- start - This is for export functionality only -->
<script src="<?php echo $base_url; ?>cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script src="<?php echo $base_url; ?>cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
<script src="<?php echo $base_url; ?>cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
<script src="<?php echo $base_url; ?>cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
<!-- end - This is for export functionality only -->
<script>
    $(document).ready(function(){
      $('#myTable').DataTable({
		  "ordering": false,
		  "lengthMenu": [[25, 50, 100,150, 200 -1], [25, 50, 100, 150, 200, "All"]]
	  });
     });
  
  
	  $( function() {
           $( "#datepicker_1" ).datepicker({ dateFormat: 'yy-mm-dd' ,changeMonth: true });
       });
            
     
function getCity(id)
{
	 
	 $.ajax({
			type: "POST",
			url: "get-city.php",	
			data: {id:id},		
			success: function(result1){
           jQuery("#city").html(result1);
			}
		});
		
}


$("#addbranch1").click(function(){
        $("#branch1").show();
		return false;
    });
    
 $("#hidebranch1").click(function(){
        $("#branch1").hide();
		return false;
    });
 
  $("#addbranch2").click(function(){
        $("#branch2").show();
		return false;
    });
    
 $("#hidebranch2").click(function(){
        $("#branch2").hide();
		return false;
    });   
     $("#addbranch3").click(function(){
        $("#branch3").show();
		return false;
    });
    
 $("#hidebranch3").click(function(){
        $("#branch3").hide();
		return false;
    });
    
function getCityB1(id)
{
	 //alert(id);
	 $.ajax({
			type: "POST",
			url: "get-city.php",	
			data: {id:id},		
			success: function(result1){
           jQuery("#b1city").html(result1);
			}
		});
		
}

function getCityB2(id)
{
	 alert(id);
	 $.ajax({
			type: "POST",
			url: "get-city.php",	
			data: {id:id},		
			success: function(result1){
           jQuery("#b2city").html(result1);
			}
		});
		
}

function getCityB3(id)
{
	 //alert(id);
	 $.ajax({
			type: "POST",
			url: "get-city.php",	
			data: {id:id},		
			success: function(result1){
           jQuery("#b3city").html(result1);
			}
		});
		
}
function rite(id)
{

  document.getElementById(id).readOnly=false;

}
 
 
  </script>

</body>
</html>

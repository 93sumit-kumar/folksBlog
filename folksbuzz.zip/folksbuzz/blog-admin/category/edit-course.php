<?php
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/functions.php');
include('../common/header.php');

//userPermissions($CONN, $USER_ROLE, 'site_users');  check the permission for user access read in function.php 
userPermissions($CONN, $USER_ROLE, 'listing');  

$edata;
if(isset($_GET['cid']))
{
   $id=$_GET['cid'];	
	$esql="SELECT * FROM course WHERE cid=".$_GET['cid'];
	$eres=mysqli_query($CONN,$esql);
	$edata=mysqli_fetch_assoc($eres);
}


if(isset($_POST['edit']))
{
  $name=clean($_POST['name']);
  $fee=clean($_POST['fee']);
  $details=clean($_POST['details']);
  $category=clean($_POST['category']);
  $usql="UPDATE course SET name='$name',ctid=$category,fee=$fee,details='$details',modify_date='$DATETIME',user_id=$USER_ID WHERE cid=$id";
 
  $ures=mysqli_query($CONN,$usql);
  if($ures)
    {
    	$_SESSION['success_msg']="Course Update Successfully";
    	unset($_POST);
      header("Location:course.php"); exit;
    }
   else 
   {
   	 $_SESSION['error_msg']="Please Try Again";
   }

}

?>
<!-- End Top Navigation -->
<style>
.form-control{
	border:1px solid #ccc !important;
}
.title{
	font-size:22px !important;
	font-weight:bold;
}
</style>
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 

<!-- Left navbar-header end -->
 <!-- Page Content -->
 <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Course</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
           <ol class="breadcrumb">
          	 <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>course/courses.php">Course</a></li>
            <li class="active"> New Course </li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
	  <?php if(isset($_SESSION['success_msg'])) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($_SESSION['error_msg'])) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']);?>.
		</div>
	  <?php } ?>
      <!-- .row -->
	  <form class="form-horizontal" method='post' enctype='multipart/form-data' data-toggle='validator' role='form'>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="course.php">
					<i class="glyphicon glyphicon-search"></i> All Courses
				</a>
			</p>
			<div class="row">
			<div class="form-group col-md-6">
                <label class="col-md-12">Select Category</label>
                <div class="col-md-12">
                 <select class='form-control' name='category'>
                  <?php 
                      $cat=fetchCategory($CONN);                  
                     foreach($cat as $category){
                  ?>
                    <option value="<?php echo $category['id']; ?>"<?php if($edata['ctid']==$category['id']){ echo 'selected';}?> ><?php echo $category['name']; ?></option>
                  <?php } ?>
                 </select>          
                </div>
          </div>
        </div> 
            <div class="form-group col-md-6">
                <label class="col-md-12">Name</label>
                <div class="col-md-12">
                  <input name='name' type="text" class="form-control" value="<?php  if(isset($edata['name'])){ echo $edata['name'];} ?>" placeholder='eg:-History' pattern="[a-zA-Z0-9 ]+" required="required">
                  <div class="help-block with-errors"></div>              
                </div>
              </div>
              <div class="form-group col-md-6">
                <label class="col-md-12">Fee</label>
                   <div class="col-md-10">
                      <input name='fee' type="text" class="form-control" pattern="\d*" value="<?php if(isset($edata['fee'])){echo $edata['fee'];} ?>"  placeholder="eg:-2000" required="required">
                      <div class="help-block with-errors"></div> 
                  </div>
			     </div>
			  <div class="form-group">
                <label class="col-md-12">Details</label>
                <div class="col-md-12">
                  <textarea class="form-control" rows="5" id="details" name='details' cols='50'><?php if(isset($edata['details'])){echo $edata['details']; }?></textarea>
                </div>
            </div>
            <div class="form-group">
                <div class="col-lg-2 col-sm-4 col-xs-12">
					    <button class="btn btn-block btn-success" type='submit' name='edit' value='submit'>Submit</button>
				    </div>
           </div>
         </div>
      </div>
    </div>
      <!-- /.row -->
   </form>
      <!-- /.row -->
  </div>
    <!-- /.container-fluid -->
</div>
 <?php include('../common/footer.php'); ?>
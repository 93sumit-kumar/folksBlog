<?php
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('submit-blog.php');
include('../common/header.php');
//userPermissions($CONN, $USER_ROLE, 'site_users');  check the permission for user access read in function.php 
//userPermissions($CONN, $USER_ROLE, 'content');  
?>
<!-- End Top Navigation -->
<style>
.form-control{
	border:1px solid #ccc !important;
}
.title{
	font-size:22px !important;
	font-weight:bold;
}
</style>
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<script>
function pageUrl(val)
	{
	   var patt=/[^a-z0-9 ]/ig;	   
	   var txt = val.replace(patt,"");
	   var url=	txt.replace(/[ ]/g,"-");
	   var url=	url.toLowerCase();
       document.getElementById('page_url').value=url;
	}
function editUrl()
	{
		document.getElementById("page_url").readOnly = false;
		document.getElementById('page_url').focus();
	}
</script>
<!-- Left navbar-header end -->
 <!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Blogs</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
           <ol class="breadcrumb">
          	 <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>blog/index.php">Blogs</a></li>
            <li class="active"> New Blog </li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
	  <?php if(isset($success_msg)) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $success_msg; unset($success_msg);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($error_msg)) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $error_msg; unset($error_msg);?>.
		</div>
	  <?php } ?>
      <!-- .row -->
	  <form class="form-horizontal" method='post' enctype='multipart/form-data'>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="index.php">
					<i class="glyphicon glyphicon-search"></i> All Blogs
				</a>
			</p>
            <div class="form-group col-md-6">
                <label class="col-md-12">Blog Title</label>
                <div class="col-md-12">
                  <input name='ctitle' type="text" class="form-control" value="" placeholder='Blog Title' onKeyUp="pageUrl(this.value);" required="required">
                </div>
              </div>
              <div class="form-group col-md-6">
                <label class="col-md-12" for="example-email">Slug <span class="help">(Blog Url) </span></label>
                <div class="col-md-10">
                  <input name='slug' type="text" readonly id="page_url"  class="form-control" placeholder="Blog slug">
                </div>
					<a href="javascript:void(0);" onClick="editUrl()" style="color:#000" >Edit Slug</a>
              </div>
			  <div class="form-group">
                <label class="col-md-12">Full Content</label>
                <div class="col-md-12">
                  <textarea class="form-control" rows="5" id="content" name='content' cols='50'></textarea>
                </div>
              </div>
			  <div class="form-group col-md-6">
                <label class="col-md-12">Select Category</label>
                <div class="col-md-12">
                  <select class="form-control" name='pid'>
					<option value="0">Default Category</option>
					<?php
					$sql="SELECT * FROM category WHERE status=1 ORDER BY cat_name";
					$res=mysqli_query($CONN, $sql);
					while($data=mysqli_fetch_array($res)) {
					?>
                     <option value="<?php echo $data['id']; ?>"><?php echo $data['cat_name']; ?></option>
					<?php } ?>
					</select>
                </div>
              </div>
			  <div class="form-group col-md-6">
                <label class="col-md-11 col-md-offset-1" style="font-weight:bold;">Show in Menu</label>
                <div class="col-md-11 col-md-offset-1">
                  <div class="radio-list">
                        <label><input name="menu" value="1" type="radio"> Yes </label> &nbsp;
                        <label> <input name="menu" value="0" checked="checked" type="radio">No </label>
                    </div>
                </div>
              </div>
			  
			 <div class="form-group">
				<label class="col-sm-12">Featured Image</label>
                <div class="col-sm-12">
					<input type="file" name='image' class="form-control" style="padding-bottom: 40px !important;">
				</div>
              </div>
 
          </div>
        </div>
      </div>
      <!-- /.row -->
	    <!-- .row -->
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <h3 class="box-title m-b-0 title">Related to On-Page SEO</h3><br>
                <div class="form-group">
                <label class="col-md-12">Meta Title<span class="help"> </span></label>
                <div class="col-md-12">
                  <input type="text" name='meta_title' class="form-control" value="" placeholder="Meta Title">
                </div>
              </div>
                      
              <div class="form-group">
                <label class="col-md-12">Meta Keyword</label>
                <div class="col-md-12">
                  <textarea name='meta_key' class="form-control" rows="3" placeholder='Enter Your Comma Separated Meta keywords'></textarea>
                </div>
              </div>
			   <div class="form-group">
                <label class="col-md-12">Meta Description</label>
                <div class="col-md-12">
                  <textarea name='meta_desc' class="form-control" rows="3" placeholder='Enter Your Meta Description Here'></textarea>
                </div>
              </div>
			  
			   <div class="form-group">
                <div class="col-lg-2 col-sm-4 col-xs-12">
					<button class="btn btn-block btn-success" type='submit' name='submit' value='submit'>Submit</button>
				</div>
              </div>
        
          </div>
        </div>
      </div>
	  </form>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
 <?php include('../common/footer.php'); ?>
 <script src="../ckeditor/ckeditor.js"></script>
<script>
        CKEDITOR.replace( 'content' );
</script>
<?php
$string='rajbir singh sehrawat----test_ }_)(*&^#4)';
$string=preg_replace("/[^A-Za-z0-9 -]/", '', $string);
$string = str_replace(' ', '-', $string);
echo $string;
echo "<br/><br/>";
echo sha1(md5('ws123!'));
echo "<br/><br/>";

echo "<br/><br/>";

$root = '/uploads/media/';
$server=$_SERVER['DOCUMENT_ROOT'];
		$DirPath=$server.$root;
		if(is_dir($DirPath)){
			$server=$_SERVER['DOCUMENT_ROOT'];
			echo $server;
			echo "Raju";
		}
		else {
			 $top=$_SERVER['PHP_SELF'];
			 $tt= explode("/", $top);
			 $server= $_SERVER['DOCUMENT_ROOT']."/".$tt[1];
			 echo $server;
			 echo "Rajbir";
			 echo $_SERVER['DOCUMENT_ROOT'];
			 
		}





echo "<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>";





?>
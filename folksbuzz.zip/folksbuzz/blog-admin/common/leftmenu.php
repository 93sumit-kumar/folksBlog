<?php
$filename=$_SERVER['PHP_SELF'];
$filename=explode('/', $filename);
$pagename=end($filename);
$directory= array_reverse($filename );
$directory = $directory[1];
$activeclass='active';
$contentPage=array('contents.php', 'new-content.php','view-Detail.php','edit-content.php');
$testimonialsPage=array('testimonials.php', 'new-testimonial.php','view-testimonial.php', 'edit-testimonial.php');
$faqPage= array('faqs.php', 'view-Faq.php', 'edit-faqs.php', 'new-faq.php', 'category.php', 'new-category.php', 'edit-category.php' );
$sitePage=array('backup.php','settings.php');
$userPage=array('users.php', 'new-user.php', 'view-user.php', 'edit-user.php','reset-password.php', 'permissions.php', 'user_log.php');
?>
<div class="sidebar" role="navigation">
 <div class="wp-sidebar-nav">					
   <ul class="wp-side-menu">
        <li class="nav-small-cap m-t-10"> &nbsp; Main Menu</li>
        <li> <a href="<?php echo $base_url;?>dashboard.php" class="waves-effect">
             <i class="fa fa-laptop"></i>
			<span class="hide-menu"> Dashboard <span class="fa arrow"></span> 
		</span></a>
        </li>
       <?php 
		$sqlPermission="SELECT * FROM permissions WHERE uid=".$USER_ROLE;
		$res=mysqli_query($CONN, $sqlPermission);
		$userRole=mysqli_fetch_assoc($res);
			
	   if($userRole['content']==1){ ?>
		<li> <a href="#" class="waves-effect <?php if($directory=='contents'){ echo 'active'; } ?>">
		  <i class="fa fa-file-text-o"></i> <span class="hide-menu">Content <span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
			   <li><a href="<?php echo $base_url; ?>contents/contents.php">All Contents</a></li>
			  <li><a href="<?php echo $base_url; ?>contents/new-content.php">New Content</a></li>
	       </ul>
       </li>		
	<?php	//}if($userRole['course']==1){  ?>
      <!--  <li> <a href="#" class="waves-effect <?php if($directory=='contents'){ echo 'active'; } ?>">
		    <i class="glyphicon glyphicon-list-alt"></i>
		    <span class="hide-menu">Course <span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
             <li><a href="<?php echo $base_url; ?>course/category.php">Category</a></li>
			   <li><a href="<?php echo $base_url; ?>course/course.php">Course</a></li>
            <li><a href="<?php echo $base_url; ?>course/new-course.php">New Course</a></li>
		   </ul>
        </li>-->
		<?php } if($userRole['advertisement']==1){ ?>
		   <li><a href="<?php echo $base_url; ?>category/category.php"><i class="fa fa-file-text-o"></i> Category</a></li>  
     <?php } if($userRole['content']==1){ ?>
		   <li> <a href="#" class="waves-effect">
		   <i class="fa fa-file"></i> <span class="hide-menu">Blogs<span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
			   <li><a href="<?php echo $base_url; ?>blog/">All Blogs</a></li>
			    <li><a href="<?php echo $base_url; ?>blog/new-blog.php">New Blog</a></li>
	      </ul>
        </li>    
     <?php } if($userRole['listing']==1){ ?>
		  <li> <a href="#" class="waves-effect <?php if($directory=='advertisement'){ echo 'active'; } ?>">
		   <i class="fa fa-video-camera"></i> <span class="hide-menu">Other's Blog<span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
			   <li><a href="<?php echo $base_url; ?>other-blog/index.php">All Blogs</a></li>
	      </ul>
        </li>     
		<?php } if($userRole['listing']==1){ ?>
		<li> <a href="#" class="waves-effect <?php if($directory=='listings'){ echo 'active'; } ?>">
		  <i class="fa fa-file-text-o"></i> <span class="hide-menu">Slider Blog<span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
             <li><a href="<?php echo $base_url; ?>slider-blog/">All Slider Blog</a></li>
			  <li><a href="<?php echo $base_url; ?>slider-blog/add-blog.php">Add Slider Blog</a></li>
	       </ul>
      </li>
      <?php } if($userRole['export']==1){ ?>
		<li> <a href="#" class="waves-effect <?php if($directory=='advertisement'){ echo 'active'; } ?>">
		   <i class="fa fa-video-camera"></i> <span class="hide-menu">Blog<span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
			   <li><a href="<?php echo $base_url; ?>other-blog/index.php">All Blogs</a></li>
			   <li><a href="<?php echo $base_url; ?>other-blog/new-blog.php">Add New Blog</a></li>
	      </ul>
        </li>  
        
		  <?php } if($userRole['settings']==1){ ?>
		  <li> <a href="#" class="waves-effect <?php if($directory=='site' ){ echo 'active'; } ?>">
		  <i class="ti-settings"></i><span class="hide-menu"> Settings <span class="fa arrow"></span></span></a>
        <ul class="nav nav-second-level">
			<?php  }if($userRole['site_backup']==1){ ?>
				<li><a href="<?php echo $base_url; ?>site/backup.php">DB Backup</a></li>
			<?php }  if($userRole['site_config']==1){ ?>
				<li><a href="<?php echo $base_url; ?>site/settings.php">Site Config</a></li>
			<?php  }  if($userRole['permissions']==1){ ?>
				<li><a href="<?php echo $base_url; ?>site/permissions.php?uid=2">Permissions</a></li>
			
			<li><a href="<?php echo $base_url; ?>site/appearance.php">Appearance</a></li>
			<?php  }  ?>
		  </ul>
        </li>
		<?php  if($userRole['site_users']==1){ ?>
		<li> <a href="#" class="waves-effect <?php if($directory=='users'){ echo 'active'; } ?>">
		  <i class="fa fa-user"></i> <span class="hide-menu">Users <span class="fa arrow"></span></span></a>
          <ul class="nav nav-second-level">
				<li><a href=" <?php echo $base_url; ?>users/users.php">All Users</a></li>
				<li><a href=" <?php echo $base_url; ?>users/new-user.php">New User</a></li>
           </ul>
      </li>
	
		  <?php  } if($userRole['user_log']==1){ ?>
		   <li><a href="<?php echo $base_url;?>users/user_log.php" class="waves-effect"><i class="glyphicon glyphicon-eye-open"></i> User Log</a></li>
		  <?php } ?>
       	        
      </ul>
    </div>
  </div>
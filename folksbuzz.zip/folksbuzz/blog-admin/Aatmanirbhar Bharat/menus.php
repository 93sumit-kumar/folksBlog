<?php
/*-----------------------------------------------------------------------------------
| $USER_ID is defined in logincheck.php file which is stored in include directory
-----------------------------------------------------------------------------------*/
include('../includes/session.php');
include('../includes/config.php');
include('../includes/logincheck.php');
include('../common/header.php');
//userPermissions($CONN, $USER_ROLE, 'site_users');  Check the permission for user access read in function.php 
userPermissions($CONN, $USER_ROLE, 'content');  
if(isset($_POST['update']))
{
	foreach($_POST AS $key=>$val){
		if($key!='update'){
			$sql="UPDATE contents SET position=$val WHERE id=$key";
			$res=mysqli_query($CONN, $sql);
			
		}
	}
}
?>
<!-- End Top Navigation -->
<!-- Left navbar-header -->
<?php include('../common/leftmenu.php');?> 
<!-- Left navbar-header end -->
<style>
input{
	border: 1px solid #7a7373;
    text-align:center;
}
</style>
<!-- Page Content -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
          <h4 class="page-title">Menu Manager</h4>
        </div>
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
             <li><a href="<?php echo $base_url; ?>dashboard.php">Dashboard</a></li>
            <li><a href="<?php echo $base_url;?>contents/contents.php">Contents</a></li>
            <li class="active">Menu</li>
          </ol>
        </div>
        <!-- /.col-lg-12 -->
      </div>
      <!-- /row -->
	  
	  <?php if(isset($_SESSION['success_msg'])) {?>
		<div class="alert alert-success alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Success!</strong> <?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']);?>.
		</div>
	  <?php } ?>
	  <?php if(isset($_SESSION['error_msg'])) {?>
		<div class="alert alert-danger alert-dismissable">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<strong>Error!</strong> <?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']);?>.
		</div>
	  <?php } ?>
      <div class="row">
        <div class="col-sm-12">
          <div class="white-box">
            <p class="text-muted m-b-30">
				<a class="btn btn-success" href="new-content.php">
					<i class="glyphicon glyphicon-plus"></i> Add New
				</a>
				<a class="btn btn-success" href="contents.php">
					<i class="glyphicon glyphicon-search"></i> All Contents
				</a>
				
			</p>
            <div class="table-responsive">
			<form action="" method="post">
			<table id="myTable" class="table table-striped table-bordered dataTable" role="grid" aria-describedby="table_info" style="width: 100%;" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th style="width:30px !important;" >S.No</th>
                  <th>Content Title</th>
                  <th>Position</th>
                </tr>
              </thead>
               <tbody>
			    <?php 
				$ii=1;
				$categoryList = fetchCategoryTree($CONN); 
				foreach($categoryList as $cl) { ?>
		        <tr>
                  <td><?php echo $ii;?></td>
                  <td><?php echo $cl["name"]; ?></td>
                  <td><input type="text" value="<?php echo $cl["position"] ?>"  name="<?php echo $cl["id"] ?>" style="width:20%;" /></td>
                </tr>
				 <?php $ii++; } ?> 
				
              </tbody>
			  <tfoot>
			  
			  </tfoot>
            </table>
			<input type="submit" value="Update Positions" class="btn btn-primary" name="update" />
			</form>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    
    </div>
    <!-- /.container-fluid -->
   
  </div>
  
 <?php include('../common/footer.php');?>
 
 